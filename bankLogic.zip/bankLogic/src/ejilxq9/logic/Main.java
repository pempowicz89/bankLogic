package ejilxq9.logic;

public class Main {
    static BankLogic myLogic = new BankLogic();

    public static void main(String[] args) {

         myLogic.getAllCustomers();

    }
}
